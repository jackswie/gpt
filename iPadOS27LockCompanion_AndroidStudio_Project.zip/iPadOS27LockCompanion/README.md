# Glass Lock — iPad-inspired Android lock-screen companion

A starter Android Studio project for a full-screen, adaptive lock-screen-style experience.

## Target device
- Lenovo Idea Tab Pro 12.7"
- Android 16 / API 36
- Portrait and landscape layouts

## Important platform limitation
This app is a **lock-screen companion / visual simulator**, not a replacement for Android's secure Keyguard. Android intentionally keeps PIN, password, fingerprint and face-unlock flows under system control. The swipe gesture in this starter only opens an in-app preview; it does not unlock the tablet or bypass authentication.

The app does not request Accessibility, overlay, device-admin, notification-reading, or other sensitive permissions. A future companion mode can be extended with user-approved integrations, but it must leave Android authentication in charge.

## Included in this starter
- Live system time and date
- Responsive portrait / landscape composition
- Animated in-app swipe transition
- Glass-like translucent cards, edge highlights and gradient reflections
- Three built-in abstract wallpapers
- Android Photo Picker for custom wallpapers
- Persists selected wallpaper URI and built-in wallpaper choice

## Build an APK
1. Install Android Studio (current stable) and Android SDK Platform 36.
2. Open this folder in Android Studio.
3. Let Gradle sync. Use JDK 17.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be under `app/build/outputs/apk/debug/`.

Or from a terminal with Gradle installed:
```bash
gradle assembleDebug
```

Install the debug APK on the tablet:
```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## Next development steps
1. Replace demo weather and battery values with real Android data providers.
2. Add user-selectable clock styles and widget configuration.
3. Add parallax/depth wallpaper treatment.
4. Add richer glass rendering. The current glass is a performant Compose approximation (layered translucency, gradient specular highlights and fine borders); it is not Apple's proprietary Liquid Glass implementation and does not yet perform true backdrop sampling blur.
5. Add optional wallpaper-service integration if you want the visual style on the home screen too.

## Notes
This project uses standard AndroidX / Jetpack Compose components and does not bundle Apple's proprietary assets, fonts, or source code.
