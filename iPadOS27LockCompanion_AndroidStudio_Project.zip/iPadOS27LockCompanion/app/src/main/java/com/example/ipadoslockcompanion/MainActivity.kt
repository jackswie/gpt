package com.example.ipadoslockcompanion

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        window.decorView.systemUiVisibility =
            (android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        setContent { GlassLockApp() }
    }
}

@Composable
private fun GlassLockApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("glass_lock", 0) }
    var customUri by remember { mutableStateOf(prefs.getString("wallpaper_uri", null)) }
    var customBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var unlockedPreview by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var wallpaperVariant by remember { mutableIntStateOf(prefs.getInt("wallpaper_variant", 0)) }

    LaunchedEffect(customUri) {
        customBitmap = try {
            customUri?.let { uri ->
                context.contentResolver.openInputStream(android.net.Uri.parse(uri))?.use {
                    BitmapFactory.decodeStream(it)
                }
            }
        } catch (_: Exception) { null }
    }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            context.contentResolver.takePersistableUriPermission(
                uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            customUri = uri.toString()
            prefs.edit().putString("wallpaper_uri", customUri).apply()
        }
    }

    BackHandler(unlockedPreview || showSettings) {
        if (showSettings) showSettings = false else unlockedPreview = false
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        WallpaperLayer(customBitmap, wallpaperVariant)
        if (unlockedPreview) {
            AnimatedContent(
                targetState = true,
                transitionSpec = { fadeIn(tween(350)) togetherWith fadeOut(tween(200)) },
                label = "homePreview"
            ) {
                Column(
                    Modifier.fillMaxSize().background(Color(0xAA080B15)).padding(32.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Welcome", color = Color.White, fontSize = 46.sp, fontWeight = FontWeight.Light)
                    Spacer(Modifier.height(10.dp))
                    Text("This is the companion preview. Android's secure lock screen remains in control.",
                        color = Color.White.copy(alpha = .78f), textAlign = TextAlign.Center)
                    Spacer(Modifier.height(24.dp))
                    GlassButton("Back to Lock Screen") { unlockedPreview = false }
                }
            }
        } else {
            LockScreen(
                now = now,
                onSwipeUnlock = { unlockedPreview = true },
                onSettings = { showSettings = true }
            )
        }

        if (showSettings) {
            SettingsSheet(
                variant = wallpaperVariant,
                hasCustom = customUri != null,
                onVariant = {
                    wallpaperVariant = it
                    prefs.edit().putInt("wallpaper_variant", it).apply()
                },
                onPick = { picker.launch(ActivityResultContracts.PickVisualMedia.ImageOnly) },
                onClear = {
                    customUri = null
                    customBitmap = null
                    prefs.edit().remove("wallpaper_uri").apply()
                },
                onClose = { showSettings = false }
            )
        }
    }
}

@Composable
private fun WallpaperLayer(bitmap: Bitmap?, variant: Int) {
    Box(Modifier.fillMaxSize()) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = "Custom wallpaper",
                modifier = Modifier.fillMaxSize(),
                contentScale = androidx.compose.ui.layout.ContentScale.Crop
            )
            Box(Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0x33000000), Color(0x11000000), Color(0x66000000)))
            ))
        } else {
            val palettes = listOf(
                listOf(Color(0xFF091A42), Color(0xFF245E8B), Color(0xFFB6D5E7)),
                listOf(Color(0xFF170E3D), Color(0xFF6E4BA8), Color(0xFFE7A8C9)),
                listOf(Color(0xFF031E25), Color(0xFF147B80), Color(0xFFB1D6B9))
            )
            val colors = palettes[variant % palettes.size]
            Canvas(Modifier.fillMaxSize()) {
                drawRect(Brush.linearGradient(colors, Offset.Zero, Offset(size.width, size.height)))
                drawCircle(
                    Brush.radialGradient(
                        listOf(Color.White.copy(alpha = .46f), Color(0x00FFFFFF)),
                        center = Offset(size.width * .70f, size.height * .30f),
                        radius = size.minDimension * .52f
                    ),
                    radius = size.minDimension * .52f,
                    center = Offset(size.width * .70f, size.height * .30f)
                )
                drawCircle(
                    Brush.radialGradient(
                        listOf(Color(0xAA83CFFF), Color(0x006DBAFF)),
                        center = Offset(size.width * .22f, size.height * .78f),
                        radius = size.minDimension * .62f
                    ),
                    radius = size.minDimension * .62f,
                    center = Offset(size.width * .22f, size.height * .78f)
                )
            }
        }
        // Soft edge shading keeps white lock-screen typography legible.
        Box(Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0x22000000), Color.Transparent, Color(0x44000000)))
        ))
    }
}

@Composable
private fun LockScreen(now: Long, onSwipeUnlock: () -> Unit, onSettings: () -> Unit) {
    val time = remember(now) { SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(now)) }
    val date = remember(now) { SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date(now)) }
    var drag by remember { mutableFloatStateOf(0f) }
    val lift by animateFloatAsState(
        targetValue = if (drag > 0) (drag / 300f).coerceIn(0f, 1f) else 0f,
        animationSpec = tween(120), label = "swipeLift"
    )

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth > maxHeight
        Column(
            Modifier.fillMaxSize()
                .padding(horizontal = if (wide) 70.dp else 28.dp, vertical = if (wide) 24.dp else 34.dp)
                .offset(y = (-lift * 48).dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                GlassPill("●  Wi-Fi   100%")
                GlassPill("Tue  •  Lenovo")
            }
            Spacer(Modifier.height(if (wide) 14.dp else 30.dp))
            Text(date.replaceFirstChar { it.uppercase() }, color = Color.White.copy(alpha = .94f), fontSize = if (wide) 18.sp else 20.sp, fontWeight = FontWeight.Medium)
            Text(
                time,
                color = Color.White,
                fontSize = if (wide) 112.sp else 104.sp,
                lineHeight = if (wide) 116.sp else 108.sp,
                fontWeight = FontWeight.Light,
                letterSpacing = (-5).sp
            )
            Spacer(Modifier.height(if (wide) 14.dp else 26.dp))
            Row(
                Modifier.fillMaxWidth(if (wide) .62f else .96f),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                GlassWidget(Modifier.weight(1f), "WEATHER", "21°", "Partly cloudy", "☀")
                Spacer(Modifier.width(12.dp))
                GlassWidget(Modifier.weight(1f), "BATTERY", "100%", "Tablet charged", "ϟ")
            }
            Spacer(Modifier.weight(1f))
            if (wide) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                    RoundControl(Icons.Filled.FlashlightOn, "Flashlight") { }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Swipe up to open", color = Color.White.copy(alpha = .85f), fontSize = 14.sp)
                        Spacer(Modifier.height(10.dp))
                        SwipeHandle()
                    }
                    RoundControl(Icons.Filled.CameraAlt, "Camera") { }
                }
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    RoundControl(Icons.Filled.FlashlightOn, "Flashlight") { }
                    RoundControl(Icons.Filled.CameraAlt, "Camera") { }
                }
                Spacer(Modifier.height(24.dp))
                Text("Swipe up to open", color = Color.White.copy(alpha = .85f), fontSize = 14.sp)
                Spacer(Modifier.height(10.dp))
                SwipeHandle()
            }
            Spacer(Modifier.height(8.dp))
        }

        // Swipe gesture is intentionally a visual demo; it does not bypass Android authentication.
        Box(
            Modifier.fillMaxSize().pointerInput(Unit) {
                detectVerticalDragGestures(
                    onVerticalDrag = { _, amount -> drag = (drag - amount).coerceIn(0f, 360f) },
                    onDragEnd = {
                        if (drag > 95f) onSwipeUnlock()
                        drag = 0f
                    }
                )
            }
        )
        Box(Modifier.align(Alignment.TopEnd).padding(18.dp)) {
            IconButton(onClick = onSettings) {
                Icon(Icons.Filled.Settings, "Settings", tint = Color.White.copy(alpha = .85f))
            }
        }
    }
}

@Composable
private fun SwipeHandle() {
    Box(Modifier.width(112.dp).height(5.dp).clip(CircleShape).background(Color.White.copy(alpha = .86f)))
}

@Composable
private fun GlassPill(text: String) {
    Box(
        Modifier.clip(CircleShape)
            .background(Brush.verticalGradient(listOf(Color.White.copy(.22f), Color.White.copy(.08f))))
            .border(1.dp, Color.White.copy(.27f), CircleShape)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) { Text(text, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium) }
}

@Composable
private fun GlassWidget(modifier: Modifier, eyebrow: String, value: String, detail: String, symbol: String) {
    Box(
        modifier.clip(RoundedCornerShape(26.dp))
            .background(Brush.linearGradient(listOf(Color.White.copy(.27f), Color.White.copy(.08f))))
            .border(1.dp, Color.White.copy(.32f), RoundedCornerShape(26.dp))
            .padding(16.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(eyebrow, color = Color.White.copy(.72f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                Text(symbol, color = Color.White, fontSize = 18.sp)
            }
            Text(value, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Medium)
            Text(detail, color = Color.White.copy(.78f), fontSize = 11.sp, maxLines = 1)
        }
    }
}

@Composable
private fun RoundControl(icon: androidx.compose.ui.graphics.vector.ImageVector, description: String, onClick: () -> Unit) {
    Box(
        Modifier.size(54.dp).clip(CircleShape)
            .background(Color.White.copy(.18f))
            .border(1.dp, Color.White.copy(.30f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        IconButton(onClick = onClick) {
            Icon(icon, description, tint = Color.White, modifier = Modifier.size(23.dp))
        }
    }
}

@Composable
private fun GlassButton(label: String, onClick: () -> Unit) {
    TextButton(
        onClick = onClick,
        modifier = Modifier.clip(CircleShape)
            .background(Color.White.copy(.17f))
            .border(1.dp, Color.White.copy(.32f), CircleShape)
    ) { Text(label, color = Color.White) }
}

@Composable
private fun SettingsSheet(
    variant: Int, hasCustom: Boolean, onVariant: (Int) -> Unit,
    onPick: () -> Unit, onClear: () -> Unit, onClose: () -> Unit
) {
    Box(Modifier.fillMaxSize().background(Color(0x77000000)), contentAlignment = Alignment.Center) {
        Column(
            Modifier.fillMaxWidth(.88f).clip(RoundedCornerShape(30.dp))
                .background(Brush.linearGradient(listOf(Color(0xEE25334B), Color(0xE9151D2D))))
                .border(1.dp, Color.White.copy(.3f), RoundedCornerShape(30.dp))
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Lock Screen Studio", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.SemiBold)
            Text("Wallpaper", color = Color.White.copy(.8f), fontSize = 14.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                repeat(3) { index ->
                    val colors = listOf(Color(0xFF245E8B), Color(0xFF6E4BA8), Color(0xFF147B80))
                    Box(
                        Modifier.weight(1f).height(58.dp).clip(RoundedCornerShape(14.dp))
                            .background(Brush.linearGradient(listOf(colors[index], Color(0xFF10172B))))
                            .border(if (variant == index && !hasCustom) 2.dp else 1.dp,
                                Color.White.copy(if (variant == index && !hasCustom) .95f else .25f),
                                RoundedCornerShape(14.dp))
                    ) {
                        TextButton(onClick = { onVariant(index); if (hasCustom) onClear() }, modifier = Modifier.fillMaxSize()) { }
                    }
                }
            }
            GlassButton("Choose a photo") { onPick() }
            if (hasCustom) GlassButton("Use built-in wallpaper") { onClear() }
            Text("Ultra Glass • Portrait + Landscape", color = Color.White.copy(.65f), fontSize = 12.sp)
            GlassButton("Done") { onClose() }
        }
    }
}
